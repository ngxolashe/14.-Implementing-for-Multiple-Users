export class User{
    name:string;
    email:string;
}